// script.js placeholder
console.log('Website loaded');